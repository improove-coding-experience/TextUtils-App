import abc, {a,c,d} from './module2.mjs';
console.log(abc); 
console.log(c); 
console.log(d); 
console.log(a); 
