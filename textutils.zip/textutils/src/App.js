// import logo from "./logo.svg";
import "./App.css";
import Alert from "./component/Alert";
import About from "./component/About";
import Navbar from "./component/Navbar";
import TextForm from "./component/TextForm";
import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./component/Home";

function App() {
  const [mode, setMode] = useState('light'); // wether dark mode is enabled or not
  const [alert, setAlert] = useState(null);

  /**
   * Shows an alert message on the screen for a duration of 1500 ms.
   * @param {string} message - The message to be displayed in the alert.
   * @param {string} type - The type of alert to be displayed (e.g., success, error, warning).
   */
  const showAlert = (message, type) => {
    setAlert({
      msg: message,
      type: type
    });

    setTimeout(() => {
      setAlert(null);
    }, 1500);
  };
  // const removeBodyClasses = () => {
  //   document.body.classList.remove('bg-light');
  //   document.body.classList.remove('bg-dark');
  //   document.body.classList.remove('bg-warning');
  //   document.body.classList.remove('bg-danger');
  //   document.body.classList.remove('bg-success');
  // }

  const toggleMode = (cls) => {
    removeBodyClasses();
    document.body.classList.remove(`bg-${mode}`);
    document.body.classList.add(`bg-${cls}`);
    if (mode === 'light') {
      setMode('dark');
      document.body.style.backgroundColor = 'black';
      document.body.style.color = 'goldenrod';
      showAlert("Dark mode has been enabled", "success");
      document.title = "TextUtils - Dark Mode";
    }
    else {
      setMode('light');
      document.body.style.backgroundColor = 'white';
      document.body.style.color = 'black';
      showAlert("Light mode has been enabled", "warning");
      document.title = "TextUtils - Light Mode";
    }
  };

  const removeBodyClasses = () => {
    document.body.classList.remove('bg-light');
    document.body.classList.remove('bg-dark');
    document.body.classList.remove('bg-primary');
    document.body.classList.remove('bg-success');
    document.body.classList.remove('bg-warning');
    document.body.classList.remove('bg-danger');
  };

  return (
    <>
      <Router>
        <Navbar title="TextUtils" Home="Home" About="About" mode={mode} toggleMode={toggleMode} />
        <Alert alert={alert} />
        <div className="container my-3">
          <Routes>
            <Route path="/home" element={<Home />} />
            <Route path="/about" element={<About mode={mode}/>} />
            <Route path="/" element={<TextForm showAlert={showAlert} heading="Enter the text to analyze below" />} />
          </Routes>
        </div>
      </Router>
    </>
  );
}

export default App;

