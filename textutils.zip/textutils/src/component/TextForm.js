import React, { useState } from "react";

export default function TextForm(props) {

  const [text, setText] = useState("");

  const handleUpClick = () => {
    const newText = text.toUpperCase();
    setText(newText);
    props.showAlert("Converted to Uppercase", "success");
  };

  //   Change Lower case

  const handleLowerClick = () => {
    // console.log("Lowercase was clicked");
    // setText("You have clicked Lowercase");
    const newText1 = text.toLocaleLowerCase();
    setText(newText1);
    props.showAlert("Converted to Lowercase", "success");
  };

  //   CHANGE TEXT TO PUNJABI LANGUAGE
  const MyComponent = () => {
    const [text, setText] = useState("");

    const handlePunjabiClick = () => {
      const newText1 = text.replace(
        /[a-zA-Z]/g,
        (char) => char.charCodeAt(0) + 0x0600 - 0x0061
      );
      setText(newText1);
      props.showAlert("Converted to Punjabi", "success");
    };
  };
  const handlecleartext = () => {
    const newText1 = "";
    setText(newText1);
    props.showAlert("Text cleared", "success");
  };
  /**
   * This function takes the current text and calculates the number of spaces per word.
   * It then creates a new text string where each line represents a word and the number of spaces and characters it contains.
   * The new text is then set as the state of the component and an alert is triggered to indicate success.
   */


  // const spaceCount_word = () => {
  //   // Split the text into an array of words, ignoring empty strings
  //   let words = text.split(" ").filter((word) => word.trim() !== "");

  //   // For each word, calculate the number of spaces it contains
  //   let spaceCountPerWord = words.map((word) => word.split("").filter((char) => char === " ").length);

  //   // For each word, calculate the number of characters it contains, ignoring spaces
  //   let charCountPerWord = words.map((word) => word.replace(/\s/g, "").length);

  //   // Create a new text string where each line represents a word and the number of spaces and characters it contains
  //   const newText1 = spaceCountPerWord
  //     .map(
  //       (count, index) =>
  //         `Word ${index + 1} has ${count} space(s) and ${
  //           charCountPerWord[index]
  //         } character(s)`
  //     )
  //     .join("\n");

  //   // Set the new text as the state of the component
  //   setText(newText1);

  //   // Trigger an alert to indicate success
  //   props.showAlert("Space count per word", "success");
  // };******************************************************************




  const spaceCount_word = () => {
  // trim first and split on one-or-more whitespace so we don't get empty strings
  const trimmed = text.trim();
  if (!trimmed) {
    props.showAlert("No text to analyze", "warning");
    return;
  }

  // words = array of non-empty tokens
  const words = trimmed.split(/\s+/);

  // total counts
  const totalWords = words.length;
  const totalCharsNoSpaces = trimmed.replace(/\s/g, "").length;

  // per-word character counts (words contain no spaces at this point)
  const perWord = words
    .map((w, i) => `Word ${i + 1} ("${w}") has ${w.length} character(s)`)
    .join("\n");

  const result = [
    `Total words: ${totalWords}`,
    `Total characters (excluding spaces): ${totalCharsNoSpaces}`,
    "",
    perWord
  ].join("\n");

  // NOTE: this replaces the text. If you don't want that, see Option B
  setText(result);
  props.showAlert("Counted words & characters (no empty strings)", "success");
};


  const handelOnChange = (event) => {
    console.log("On change");
    setText(event.target.value);
    props.showAlert("Text changed", "success");
  };

  // reverse order

  const Reverse_order = () => {
    console.log("inverse click is triggered");
    const newText1 = text.split("").reverse().join("");
    setText(newText1);
    props.showAlert("Text reversed", "success");
  };

  // speak and pause functions
  const speak = () => {
    let msg = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(msg);
    const toogle = document.getElementById("toggle");
    if (toogle.textContent == "Speak") {
      toogle.innerHTML = "Stop";
    } else {
      toogle.innerHTML = "Speak";
      if ((toogle.innerHTML = "Speak")) {
        window.speechSynthesis.cancel();
      }
    }
    props.showAlert("Text spoken", "success");
  };

  // download text
  const downloadText = () => {
    const element = document.createElement("a");
    const file = new Blob([text], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = "text.txt";
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    props.showAlert("Text downloaded", "success");
  };

  // copy to clipboad
  const copyToClipboard = () => {
    navigator.clipboard.writeText(text)
      .then(() => props.showAlert("Text copied to clipboard", "success"))
      .catch((err) => console.error(err));
  };

  const cancelStrikethroughText = () => {
    const newText1 = text
      .split("~~\n")
      .filter((line) => line !== "")
      .join("\n");
    setText(newText1);
    props.showAlert("Strikethrough text removed", "success");
  };

  return (
    <div>
      <div className="container">
        <div className="mb-3">
          <h1>{props.heading}</h1>
          <textarea
            className="form-control"
            value={text}
            onChange={handelOnChange}
            style={{
              backgroundColor: props.mode === "light" ? "white" : "rgb(179 21 21 / 0%)",
              color: props.mode === "light" ? "white" : "#ff8000ff",
            }}
            id="myBox"
            rows="8"
          ></textarea>
        </div>
        <button
          disabled={text.length === 0 ? true : false}className="btn btn-outline-success mx-1 my-1"
          onClick={handleUpClick}
        >
          Convert to UpperCase
        </button>

        <button disabled={text.length === 0 ? true : false}
          className="btn btn-outline-warning mx-1 my-1"
          onClick={handleLowerClick}
        >
          Convert to LowerCase
        </button>
        <button disabled={text.length === 0 ? true : false}
          type="button"
          className="btn btn-outline-danger"
          onClick={handlecleartext}
        >
          Clear Text
        </button>
        <button disabled={text.length === 0 ? true : false}
          type="button"
          className="btn btn-outline-danger mx-1 my-1"
          onClick={spaceCount_word}
        >
          spaceCount_word
        </button>

        <button disabled={text.length === 0 ? true : false}
          type="button"
          className="btn btn-outline-danger mx-1 my-1"
          onClick={() => {
            const newText1 = text.replace(/([a-z])/gi, (match, char) => {
              const punjabiMap = {
                a: "\u0A05",
                b: "\u0A06",
                c: "\u0A0A",
                d: "\u0A0F",
                e: "\u0A47",
                f: "\u0A48",
                g: "\u0A09",
                h: "\u0A39",
                i: "\u0A3E",
                j: "\u0A4A",
                k: "\u0A15",
                l: "\u0A32",
                m: "\u0A2E",
                n: "\u0A28",
                o: "\u0A4B",
                p: "\u0AA4",
                q: "\u0AA5",
                r: "\u0AB9",
                s: "\u0A38",
                t: "\u0A4D",
                u: "\u0A51",
                v: "\u0AA6",
                w: "\u0AA7",
                x: "\u0AA8",
                y: "\u0AAF",
                z: "\u0AB0",
                " ": "\u0A4E",
              };
              return punjabiMap[char.toLowerCase()] || char;
            });
            setText(newText1);
            props.showAlert("Converted to Punjabi", "success");
          }}
        >
          CHANGE TO PUNJABI
        </button>

        <button disabled={text.length === 0 ? true : false}
          type="button"
          className="btn btn-outline-danger mx-1 my-1"
          onClick={Reverse_order}
        >
          Reverse order
        </button>

        {/* speak function button */}

        <button disabled={text.length === 0 ? true : false}
          type="submit"
          onClick={speak}
          className="btn btn-warning mx-2 my-2"
          id="toggle"
        >
          Speak
        </button>

        {/* download text */}
        <button disabled={text.length === 0 ? true : false} className="btn btn-outline-success mx-1 my-1" onClick={downloadText}>
          Download Text
        </button>

        {/* copy to text */}

        <button disabled={text.length === 0 ? true : false}
          className="btn btn-outline-primary mx-1 my-1"
          onClick={copyToClipboard}
        >
          Copy to Clipboard
        </button>
        <button disabled={text.length === 0 ? true : false}
          className="btn btn-outline-primary mx-1 my-1"
          onClick={cancelStrikethroughText}
        >
          Cancel text
        </button>
      </div>
      <div className="container my-3">
        <h1>Your Text Summary</h1>
        <p>
          Words count is {text.trim().split(/\s+/).filter(word => word !== "").length} and character count is{" "}
          {text.replace(/\s/g, "").length}{" "}
        </p>
        <p>{0.008 * text.split("/\s+/").filter(word => word.trim() !== "").length} Minutes Read </p>
        <h2>Preview</h2>
        <p style={{color: props.mode === "dark" ? "white" : "black"}} >
          {text.length > 0 ? text : "Enter Something to Preview"}
        </p>
      </div>
    </div>
  );
}
