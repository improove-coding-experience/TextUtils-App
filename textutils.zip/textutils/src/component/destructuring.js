// script.js > [e] arr

// destructuring = it is a way to unpack values from array or 
// objects into separate variables,

// syntax
// const arr = [1, 2, 3];
// const [a, b, c] = arr;
// // const a = arr[0];

// console.log(a, b, c);
  

// ********   How to skiping the item/variable ********

const arr = [10, 20, 30];
const [x, , z] = arr;

console.log(x,z);


// ********   destructuring Objects ********

const person = {
    boyname: "Harry",
    age: 21
};

const {boyname, age} = person;
console.log(boyname, age);

