import React, { useState } from "react";

export default function TextForm(props) {
  const [text, setText] = useState("Enter text here");

//   const handleUpClick = () => {
    // console.log("Uppercase was clicked");
    // setText("You have clicked Uppercase");  
//      const newText = text.toUpperCase();
//     setText(newText);
//   };

  const handleUpClick = () => {
    const newText = text.toUpperCase();
    const textAreaStyle = {
      color: "gold",
      backgroundColor: "black",
      MozBoxSizing: "border-box",
      WebkitBoxSizing: "border-box",
      boxSizing: "border-box",
      animation: "glow 0.5s ease-in-out infinite alternate",
    };
    const textAreaElement = document.getElementById("myBox");
    Object.assign(textAreaElement.style, textAreaStyle);
    textAreaElement.style.textShadow = "0 0 5px goldenrod";
    textAreaElement.style.animation = "glow 0.5s ease-in-out infinite alternate";
    setText(newText);
  };



  
//   Change Lower case

 const handleLowerClick = () => {
    // console.log("Lowercase was clicked");
    // setText("You have clicked Lowercase");  
     const newText1 = text.toLocaleLowerCase();
    setText(newText1);
  };


  const handelOnChange = (event) => {
    console.log("On change");
    setText(event.target.value);
  };

  // text = "new text";  //Wrong way
  // setText('ghjghjk');  //correct way

  return (
    <div>
      <div className="mb-3">
        <h2>{props.heading}</h2>
        <textarea
          className="form-control"
          value={text}
          onChange={handelOnChange}
          id="myBox"
          rows="8"
        ></textarea>
      </div>
      <button className="btn btn-outline-warning" onClick={handleUpClick}>
        Convert to UpperCase
      </button><br /><br />
      <button className="btn btn-outline-warning" onClick={handleLowerClick}>
        Convert to LowerCase
      </button>
    </div>
  );
}
