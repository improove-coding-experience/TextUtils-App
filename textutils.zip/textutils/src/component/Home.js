import React from "react";

const Home = () => {
  return (
    <div className="container my-3">
      <h1 className="display-4">Welcome to Text Utils</h1>
      <p className="lead">
        A utility which can be used to manipulate your text in the way you want.
      </p>
    </div>
  );
};

export default Home;
