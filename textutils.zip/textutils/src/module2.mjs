const a = "Harry";
const b = "Rohan";
const c = "Akash";
const d = "Priyanka";

export default b;
export  {a};
export  {c};
export  {d};
